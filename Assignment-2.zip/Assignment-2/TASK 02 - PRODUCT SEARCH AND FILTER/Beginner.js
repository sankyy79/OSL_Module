
let grid = document.querySelector(".products");
let filterInput = document.getElementById("filterInput");


//fetching the data from api into variable and making it iterable
fetch('https://mocki.io/v1/4d947516-e382-4ec3-a233-151c62af4bb4')
    .then(res => res.json())
    .then(json => {

        // iterating products
        for (let value of json) {
            addElement(grid, value)
        }
        // console.log(json);

    });


// get value from the api create dynamic element
function addElement(appendIn, value) {
    let div = document.createElement('div');
    div.className = "item card";
    let { make, model, type, price, image } = value;

    div.innerHTML = `
         
            <img src="${image}" class="img mx-auto" alt="img1">
            <div class="product-text">
            <p class="title">Make : ${make}</p>
            <p class="model">Model : ${model}</p>
            <p class="type">Type : ${type}</p>
            <p class="price">Price : ${price}</p>
            </div>
       
    `;
    appendIn.appendChild(div);
}

// filtering based on search field value 
function filterProducts(){
    let filterValue = filterInput.value.toUpperCase();
    let item = grid.querySelectorAll('.item')
    // console.log(filterValue);

    for (let i = 0; i < item.length; i++){
        let spanmake = item[i].querySelector('.title');
        let spanmodel = item[i].querySelector('.model');
        let spantype = item[i].querySelector('.type');
        let spanprice = item[i].querySelector('.price');

        if(spanmake.innerHTML.toUpperCase().indexOf(filterValue) > -1 ||spanmodel.innerHTML.toUpperCase().indexOf(filterValue) > -1 || spantype.innerHTML.toUpperCase().indexOf(filterValue) > -1 || spanprice.innerHTML.toUpperCase().indexOf(filterValue) > -1){
            item[i].style.display = "initial";
        }else{
            item[i].style.display = "none";
        }

    }
}


//filtering based on selected option
function filterOptionProduct(value,id){
    let filterdValue = value.toUpperCase();
    let item = grid.querySelectorAll('.item')
    console.log(filterdValue);

    for (let i = 0; i < item.length; i++){
        let temp=item[i].querySelector('.'+id);
        
        if(temp.innerHTML.toUpperCase().indexOf(filterdValue) > -1){
            item[i].style.display = "initial";
        }else{
            item[i].style.display = "none";
        }

    }
}


