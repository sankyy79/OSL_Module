// Select the input and ul elements
const input = document.querySelector("input");
const list = document.querySelector("ul");
const succdele = document.querySelector(".blip");
var indexval=0;

// Initialize an empty array to hold the todos
let todos = [];

// Function to display the todos on the screen
function displayTodos() {
  // Clear the list element
  list.innerHTML = "";
  // Loop through the todos array and add each todo as a list item
  for (let i = 0; i < todos.length; i++) {
    const todo = todos[i];
    const li = document.createElement("li");
    const span = document.createElement("span");
    li.textContent = todo;

    // Add edit button to each list item
    const editButton = document.createElement("button");
    editButton.innerHTML = '<i class="fa fa-lg fa-pencil-square-o edit-btn" aria-hidden="true"></i>';
    editButton.addEventListener("click", function () {
      indexval=i;
      location.href = "#input-val";
      editTodoAtIndex1();
    });
    span.appendChild(editButton);

    // Add delete button to each list item
    const deleteButton = document.createElement("button");
    deleteButton.innerHTML = '<i class="fa fa-lg fa-trash del-btn" aria-hidden="true"></i>';
    deleteButton.addEventListener("click", function () {
      deleteTodoAtIndex(i);
    });
    span.appendChild(deleteButton);
    li.appendChild(span);
    list.appendChild(li);
  }
}

// Call the displayTodos function to initially display the todos
displayTodos();

// Function to add a new todo
function addTodo() {
  // Get the input value and add it to the todos array
  const todo = input.value;
  if (todo) {
    todos.push(todo);
    // Display the new todo
    displayTodos();//here to add --> to do successfully added
    succdele.innerHTML = 'Item Added To The List'
    succdele.classList.add('todoAdd');
    setTimeout(function () {
      succdele.innerHTML = ''
      succdele.classList.remove('todoAdd');

    }, 2000);
    // Clear the input box
    input.value = "";
  }
}

function editTodo() {
  
  // Get the input value and add it to the todos array
  const newtodo = input.value;
  if (newtodo) {
    console.log(indexval);
    todos[indexval] = newtodo; 
    editTodoAtIndex2();
    displayTodos();
    succdele.innerHTML = 'Item Updated'
    succdele.classList.add('todoAdd');
    setTimeout(function () {
      succdele.innerHTML = ''
      succdele.classList.remove('todoAdd');

    }, 2000);
    // Clear the input box
    input.value = "";
  }
}

function editTodoAtIndex1(){
  let  addbtn = document.querySelector(".add-button");
  addbtn.classList.add('add-button-disp');
  let editbtn=document.querySelector(".edit-button");
  editbtn.classList.remove('editxx');
}

function editTodoAtIndex2(){
  let  addbtn = document.querySelector(".add-button");
  addbtn.classList.remove('add-button-disp');
  let editbtn=document.querySelector(".edit-button");
  editbtn.classList.add('editxx');
}


// Function to delete a todo at a specific index
function deleteTodoAtIndex(index) {
  // Remove the todo from the todos array and display the updated todos
  todos.splice(index, 1);
  displayTodos(); //to delete to do show that to do has been successfully deleted
  succdele.innerHTML = 'Item Removed'
  succdele.classList.add('todoDel');
  setTimeout(function () {
    succdele.innerHTML = ''
    succdele.classList.remove('todoDel');

  }, 2000);
}

function clearAll() {
  while (todos.length > 0) {
    todos.pop();
    displayTodos();

  }
  succdele.innerHTML = 'Cleared All'
  succdele.classList.add('todoDel');
  setTimeout(function () {
    succdele.innerHTML = ''
    succdele.classList.remove('todoDel');

  }, 2000);

}
// Attach an event listener to the add button to call the addTodo function when clicked
document.querySelector(".add-button").addEventListener("click", addTodo);
document.querySelector("#button").addEventListener("click", clearAll);
document.querySelector(".edit-button").addEventListener("click",editTodo);




















// // Select the input and ul elements
// const input = document.querySelector("input");
// const list = document.querySelector("ul");

// // Initialize an empty array to hold the todos
// let todos = [];

// // Function to display the todos on the screen
// function displayTodos() {
//   // Clear the list element
//   list.innerHTML = "";
//   // Loop through the todos array and add each todo as a list item
//   for (let i = 0; i < todos.length; i++) {
//     const todo = todos[i];
//     const li = document.createElement("li");
//     li.textContent = todo;
//     // Add edit button to each list item
//     const editButton = document.createElement("button");
//     editButton.textContent = "<i class="fa-solid fa-pen-to-square" style="color: #366525;"></i>";
//     editButton.addEventListener("click", function() {
//       editTodoAtIndex(i);
//     });
//     li.appendChild(editButton);
//     // Add delete button to each list item
//     const deleteButton = document.createElement("button");
//     deleteButton.textContent = "Delete";
//     deleteButton.addEventListener("click", function() {
//       deleteTodoAtIndex(i);
//     });
//     li.appendChild(deleteButton);
//     list.appendChild(li);
//   }
// }

// // Call the displayTodos function to initially display the todos
// displayTodos();

// // Function to add a new todo
// function addTodo() {
//   // Get the input value and add it to the todos array
//   const todo = input.value;
//   if (todo) {
//     todos.push(todo);
//     // Display the new todo
//     displayTodos();
//     // Clear the input box
//     input.value = "";
//   }
// }

// // Function to edit a todo at a specific index
// function editTodoAtIndex(index) {
//   // Prompt the user for the new todo text
//   const newTodo = prompt("Enter the new todo text:");
//   // If the user entered a new todo, update the todos array and display the updated todos
//   if (newTodo) {
//     todos[index] = newTodo;
//     displayTodos();
//   }
// }

// // Function to delete a todo at a specific index
// function deleteTodoAtIndex(index) {
//   // Remove the todo from the todos array and display the updated todos
//   todos.splice(index, 1);
//   displayTodos();
// }

// // Attach an event listener to the add button to call the addTodo function when clicked
// document.querySelector("#add-button").addEventListener("click", addTodo);
