$(document).ready(function () {

	// Name should have atleast 3 characters
	$('#contact_name').on('input', function () {
		var input = $(this);
		var is_name = input.val();
		var name_len = is_name.length;
		if (name_len >= 3) { input.removeClass("invalid").addClass("valid"); }
		else { input.removeClass("valid").addClass("invalid"); }
	});

	//email should contain all the things that required 
	$('#contact_email').on('input', function () {
		var input = $(this);
		var regx = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
		var is_email = regx.test(input.val());
		if (is_email) { input.removeClass("invalid").addClass("valid"); }
		else { input.removeClass("valid").addClass("invalid"); }
	});


	$('#contact_pass').on('input', function () {
		var input = $(this);
		var password = input.val();
		var len = password.length;

		if (len >= 6) { input.removeClass("invalid").addClass("valid"); }
		else { input.removeClass("valid").addClass("invalid"); }
	});


	$('#contact_conf_pass').on('input', function () {
		var input = $(this);
		var conf_password = input.val();
		var password = document.getElementById("contact_pass").value;
		var confirmPassword = document.getElementById("contact_conf_pass").value;

		if (password == confirmPassword) { input.removeClass("invalid").addClass("valid"); }
		else { input.removeClass("valid").addClass("invalid"); }

	});



	$("#contact_submit button").click(function (event) {
		var form_data = $("#contact").serializeArray();
		var error_free = true;
		for (var input in form_data) {
			var element = $("#contact_" + form_data[input]['name']);
			var valid = element.hasClass("valid");
			var error_element = $("span", element.parent());
			if (!valid) { error_element.removeClass("error").addClass("error_show"); error_free = false; }
			else { error_element.removeClass("error_show").addClass("error"); }
		}
		if (!error_free) {
			event.preventDefault();
		}
		else {
			var username = $('#contact_name').val();
			var email = $('#contact_email').val();
			var password = $('#contact_pass').val();
			localStorage.setItem("username", username);
			localStorage.setItem("email", email);
			localStorage.setItem("password", password);
			alert('No errors: Form will be submitted');
		}
	});

});


