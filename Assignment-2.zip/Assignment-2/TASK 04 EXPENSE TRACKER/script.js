// Select the input and ul elements
const txt = document.querySelector(".txt");
const amount = document.querySelector(".amount");
const list = document.querySelector("ul");

// Initialize an empty array to hold the todos
let txtArr = [];
let amountArr=[];

// var income = 0;
// var expence = 0;
// var balance = 0;
function allfunction(amountcontent) {
 
  let result = amountcontent.slice(0, 1);
  console.log(result);
  if (result ==='+') {

    income += parseInt(amountcontent.slice(1, amountcontent.length));
    document.querySelector("#income").innerHTML = '$'+ income;
  }
  else {
    expence-= parseInt(amountcontent.slice(1, amountcontent.length));
    document.querySelector("#Expence").innerHTML = '$'+ expence;
  }

  balance = income - expence;
  document.querySelector("#balance").innerHTML = '$'+ balance;
}

// Function to display the todos on the screen
function displayTodos() {
  // Clear the list element
  var income = 0;
  var expence = 0;
  var balance = 0;
  list.innerHTML = "";
  // Loop through the todos array and add each todo as a list item
  for (let i = 0; i < txtArr.length; i++) {
    const textcontent = txtArr[i];
    const amountcontent=amountArr[i];
    const li = document.createElement("li");
    li.classList.add
    // li.textContent = 'sandeep';
    li.innerHTML= "<span class='litxt'>"+textcontent+"</span><span class='liamount'>"+amountcontent+"</span>";
    
    // allfunction(amountcontent);
    let result = amountcontent.slice(0, 1);
  if (result ==='+') {
    li.classList.add('positive')
    income += parseInt(amountcontent.slice(1, amountcontent.length));
    document.querySelector("#income").innerHTML = '$'+ income+".00";
  }
  else {
    li.classList.add('negative')
    expence+= parseInt(amountcontent.slice(1, amountcontent.length));
     //bcz when we do 0-expence it has - sign so slice it
    document.querySelector("#Expence").innerHTML = '$'+ expence+".00";
  }

   list.appendChild(li);
  }
  // console.log(income,expence);
  balance = income - expence; 
  document.querySelector("#balance").innerHTML = '$'+ balance+".00";
}

// Call the displayTodos function to initially display the transactions
displayTodos();

// Function to add a new todo
function addTodo() {
  // Get the input value and add it to the todos array
  const txtval = txt.value;
  const amountval =amount.value;
  if (txtval && amountval) {
    txtArr.push(txtval);
    amountArr.push(amountval);
    // Display the new todo
    displayTodos();
    // Clear the input box
    txt.value = "";
    amount.value="";
  }
}
document.querySelector("#button").addEventListener("click", addTodo);


