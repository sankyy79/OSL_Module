function copypass() {
    // Get the text field
    var copyText = document.getElementById("password");
  
    // Select the text field
    copyText.select();
    copyText.setSelectionRange(0, 99999); // For mobile devices
  
     // Copy the text inside the text field
    navigator.clipboard.writeText(copyText.value);
  
    // Alert the copied text
    alert("Copied the text: " + copyText.value);
  }

  $(".inp-button").click(copypass);


  function generatePassword() {
    var length = document.getElementById("length").value;
    var includeUppercase = document.getElementById("uppercase").checked;
    var includeLowercase = document.getElementById("lowercase").checked;
    var includeNumbers = document.getElementById("numbers").checked;
    var includeSpecial = document.getElementById("special").checked;
    // console.log(length+" "+includeLowercase+" "+includeUppercase+" "+ includeSpecial+" "+includeNumbers);
  
    var uppercaseChars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    var lowercaseChars = "abcdefghijklmnopqrstuvwxyz";
    var numberChars = "0123456789";
    var specialChars = "!@#$%^&*()_-+=<>?";
  
    var password = "";
    var availableChars = "";
  
    if (includeUppercase) {
      availableChars += uppercaseChars;
    }
  
    if (includeLowercase) {
      availableChars += lowercaseChars;
    }
  
    if (includeNumbers) {
      availableChars += numberChars;
    }
  
    if (includeSpecial) {
      availableChars += specialChars;
    }
  
    if (availableChars.length === 0) {
      alert("Please select at least one option.");
      return;
    }
  
    for (var i = 0; i < length; i++) {
      var randomIndex = Math.floor(Math.random() * availableChars.length);
      password += availableChars.charAt(randomIndex);
    }
  
    document.getElementById("password").value = password;
  }


  $(".button").click(generatePassword);
  