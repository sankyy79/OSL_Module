
let count = 0;
var next = document.querySelector("#next");
var prev = document.querySelector("#prev");
var prev_text = document.querySelector("#prev-text");
var next_text = document.querySelector("#next-text");
var image=document.querySelector("#img");
var head=document.querySelector("#heading");
var headtext=document.querySelector("#heading-text");
var neighbor=document.querySelector("#neighbor");
var neighis=document.querySelector("#neigh");

(async () => {
    const getData = async () => {
        const response = await fetch("./database/datafile.json");
        const data = await response.json();
        return data;
    };

    let arr = await getData();
    

    var map = L.map('map').setView([26.450595, -81.999207], 12.4);
    L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 19,
        attribution: '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>'
    }).addTo(map);

    // console.log(arr.length);
    for (let i = 1; i < arr.length; i++) {
        let lat = arr[i].geolocation.lat;
        let lng = arr[i].geolocation.lng;
        var circle = L.circle([lat, lng], {
            color: '#f5f5f5',
            fillColor: '#153c4a',
            fillOpacity: 1,
            radius: 300
        }).addTo(map);

       
    }

     //function to match the id with the use of count value
    function matchID(idmatch) {
        for (let i = 0; i < arr.length; i++) {
            if (arr[i].id === idmatch) {
                return i;
            }
        }
    }

    // Function used to remove circle of the previous visited location
    function circleremoval(indexx) {
        var index = matchID(indexx);
        var lat = arr[index].geolocation.lat;
        var lng = arr[index].geolocation.lng;
        var crc = L.circle([lat, lng], {
            color: '#f5f5f5',
            fillColor: '#153c4a',
            fillOpacity: 1,
            radius: 300
        }).addTo(map);


    }


    //perfrom operation when someone click on right angle
    next.addEventListener("click", function () {


        if (count > 21) {
            count = 0;
        }
        if(count>0){
          
            circleremoval(count);
        }
        count++;
        var index = matchID(count);
        var textcontent1 = arr[index].title;
        var textcontent2 = arr[index+1].title;
        var lat = arr[index].geolocation.lat;
        var lng = arr[index].geolocation.lng;
        next_text.innerHTML = textcontent2;
        prev_text.innerHTML= textcontent1;
        var img=arr[index].image;
        var headingtext=arr[index].description;
        image.setAttribute("src",img);
        head.innerHTML=textcontent1;
        headtext.innerHTML=headingtext;
        neighbor.classList.remove("disp");
        neighbor.classList.add("neighbour");
        neighis.innerHTML=arr[index].related_neighborhood.title;
        map.setView([lat, lng], 14);
        var crc = L.circle([lat, lng], {
            color: '#f5f5f5',
            fillColor: '#153c4a',
            fillOpacity: 1,
            radius: 200
        }).addTo(map);

    })
    
    //perform operation when someone clicked on left angle
    prev.addEventListener("click", function () {
        if (count <= 1) {
            count = 1;
           
        }
       
        else {

            if (count >=2) {
                circleremoval(count);               
            }
            count--;
            var index = matchID(count);
            var textcontent1 = arr[index].title;
            var textcontent2 = arr[index-1].title;
            var lat = arr[index].geolocation.lat;
            var lng = arr[index].geolocation.lng;
            prev_text.innerHTML = textcontent2;
            next_text.innerHTML = textcontent1;
            if(index>1){
                neighis.innerHTML=arr[index-1].related_neighborhood.title;
            }
            map.setView([lat, lng], 14);
            var crc = L.circle([lat, lng], {
                color: '#f5f5f5',
                fillColor: '#153c4a',
                fillOpacity: 1,
                radius: 200
            }).addTo(map);
        }


    })

})();


