

const firstName = document.getElementById("contact_name");
const email = document.getElementById("contact_email");
const password = document.getElementById("contact_pass");
const confirmPassword = document.getElementById("contact_conf_pass");
// Button
const btnSignup = document.getElementById("contact_submit");


function signUp() {

  document.querySelector("body").classList.add("bodyback");
  const first_name = contact_name.value;
  const e_mail = contact_email.value;
  const pass_word = contact_pass.value;
  const confirm_Password=contact_conf_pass.value;

  // If either of the values is empty
  if (!first_name || !e_mail || !pass_word) {
    alert("Every field is required")
    return;
  }

  if(first_name.length<3){
    return alert("Name should have atleast 3 characters");
  }

  if(pass_word.length<6){
     return alert("Password should have atleast 6 characters");
  }

  if(pass_word!=confirm_Password){
     return alert("Password does not matches");
  }

  //set user input into JSON
  let user_data = {
    firstName: first_name,
    email: e_mail,
    password: pass_word
  }

  // convert to string
  let user_data_str = JSON.stringify(user_data.email);
  console.log(user_data_str);

  //get to localstorage if there is existing user ||or make empty array[]
  let clientsArr = JSON.parse(localStorage.getItem('users')) || [];
 

  for (var i = 0; i < clientsArr.length; i++) {
    let temp = JSON.stringify(clientsArr[i].email);
    console.log(temp, user_data_str);
    if (temp === user_data_str) {

      return alert('User already exists')
    }
  }

  //i push ang new user sa array
  clientsArr.push(user_data);

  //save to localstorage
  localStorage.setItem('users', JSON.stringify(clientsArr));

}
// Attach listener;
btnSignup.addEventListener('click', signUp);



function myFunction() {
  var x = document.getElementById("mySidenav");
  if (x.style.width === "250px") {
    x.style.width = "0";
  } else {
    x.style.width = "250px";
  }
}



// Get the modal
var modal = document.getElementById("myModal");

// Get the button that opens the modal
var btn = document.getElementById("myBtn");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks the button, open the modal 
btn.onclick = function () {
  modal.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span.onclick = function () {
  modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function (event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
}




