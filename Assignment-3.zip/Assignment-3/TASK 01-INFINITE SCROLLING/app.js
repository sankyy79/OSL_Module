
    (async () => {
        const getData = async () => {
            const response = await fetch("https://jsonplaceholder.typicode.com/posts?_limit=5&_page=1");
            const data = await response.json();
            return data;
        };

        let arr = await getData();
        // console.log(arr[0].name);
        const container = document.querySelector('.container');
        const sub_container = document.querySelector('.sub-container');
        const URL = 'https://jsonplaceholder.typicode.com/posts?_limit=5&_page=1'


        function loadImages(numImages = 5) {
            var i = 0;
            while (i < numImages) {
                const li = document.createElement('li');
                const title = document.createElement('h1');
                const body = document.createElement('p');
        
                title.innerHTML = arr[i].title;
                body.innerHTML = arr[i].body;
                // appending title and body content into li 
                li.appendChild(title);
                li.appendChild(body);

                // appending li into sub container
                sub_container.appendChild(li);
                i++;
            }
        }

        loadImages();



        // listen for scroll event and load more images if we reach the bottom of window
        window.addEventListener('scroll', () => {
            console.log("scrolled", window.scrollY) //scrolled from top
            console.log(window.innerHeight) //visible part of screen
            if (window.scrollY + window.innerHeight >= document.documentElement.scrollHeight) {
                loadImages();
            }
        })


    })();




