var input = [];
var op = [];
var temp = '';


// to print value on the calculator screen
function scrn(value) {
    var pre = $(".result").attr('placeholder');

    $(".result").attr("placeholder", pre + value);
    
}
//string to int converter
function parseint(valuetemp) {
    var value_temp = parseFloat(valuetemp);
    
    input.push(value_temp);
    temp = '';

}

// to calculate the input values
function calculate() {
   
    var result = 0;
    while (op.length > 0) {
        var i = op.length - 1;
        var j = input.length - 1;
       
        if (op[i] == '+') {
            result = input[j] + input[j - 1];

        }
        else if (op[i] == '-') {
            result = input[j - 1] - input[j];

        } else if (op[i] == '*') {
            result = input[j] * input[j - 1];

        } else if (op[i] == '/') {
            result = input[j - 1] / input[j];

        }

        input.pop();
        input.pop();
        input.push(result);
        op.pop();
        
        $(".result").attr("placeholder", " ");
       
    }

    scrn(input[0]);
}

// to detect any input value
function inputdetect(value) {
    if (value >= 0 && value <= 9) {

        if (op.length == 0) {
            $(".result").attr("placeholder", " ");

        }
        if (input.length == 0) {
            temp = temp + value;
            scrn(temp);
        }
        else {
            temp = temp + value;
            scrn(value);
        }

    }
    else if (value == '/' || value == '*' || value == '-' || value == '+') {
        if (temp !== '') { parseint(temp); temp = ''; }
        op.push(value);
        scrn(value);
    }
    else if (value == '=') { 
        parseint(temp);

        scrn(value);
        calculate();
    }
    else {
        input = [];
        op = [];
        $(".result").attr("placeholder", " ");
        temp = '';
    }
}
$("button").click(function (event) {
    var value = event.target.innerHTML;
    inputdetect(value);

});

$("body").keypress(function (event) {
    inputdetect(event.key);
});